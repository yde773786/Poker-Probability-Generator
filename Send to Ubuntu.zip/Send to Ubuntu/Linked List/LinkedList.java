class LinkedList{
    Node start;
    Node ptr;
    public void add_at_end(int n){
        Node pt = null;
        ptr = new Node(n);
        if(start == null){
            start = ptr;
        }
        else {
            for(pt= start; pt.link !=null; pt = pt.link){
            }
            pt.link = ptr;
        }
    }

    public void add_node_at_beginning(int A){
        Node a=new Node(A);
        a.link = start;
        start = a;
    }

    public void add_at_location(int A, int location){
        ptr = new Node(A);
        Node pt = null;
        int finder = 0;
        for(pt= start; pt.link !=null; pt = pt.link){
            finder++;
            if(finder == location){
                break;
            }
        }
        ptr.link = pt.link;
        pt.link = ptr;
    }

    public void del_at_location(int location){
        Node pt = null;
        int finder = 0;
        for(pt= start; pt.link !=null; pt = pt.link){
            finder++;
            if(finder == location){
                break;
            }
        }
        pt.link = pt.link.link;
    }

    public void del_at_end(){
        Node pt = null;
        if(start == null){
            return;
        }
        else{
            for(pt= start; pt.link.link !=null; pt = pt.link){
                continue;
            }
            pt.link = null;
        }

    }

    public void del_front(){
        if(start == null){
            return;
        }
        else {
            start = start.link;
        }
    }

    public int sum(){
        Node pt = null;
        int sum = 0; 
        for(pt= start; pt.link !=null; pt = pt.link){
            sum+= pt.data;
        }
        sum+= pt.data;
        return sum;
    }

    public void sort(){
        Node pt, pt_2;
        if(start == null){
            return ;
        }
        else{
            for(pt= start; pt !=null; pt = pt.link){
                for(pt_2 = start; pt_2.link != null; pt_2 = pt_2.link){
                    if(pt_2.data >pt_2.link.data)
                    {
                        int tmp = pt_2.data;
                        pt_2.data = pt_2.link.data;
                        pt_2.link.data = tmp;
                    }
                }
            }
        }
    }

    public  void reverse()
    {
        Node pt, pt_2;
        Node tmp = start;
        int cnt = 0;
        int cnt_2 = 0;int cnt_2_changer = 0;
        if(start == null){
            return ;
        }
        else{
            for(pt = start ; pt !=null ; pt = pt.link){
                cnt++;
            }
        }
        int chk_cnt = cnt;
        for(pt= start; cnt != chk_cnt/2 ; pt = pt.link){
            cnt_2_changer++;
            cnt_2 = cnt_2_changer;
            for(pt_2 = tmp; cnt_2 != cnt; pt_2 = pt_2.link){
                cnt_2++;
            }
            int temporary = tmp.data;
            tmp.data = pt_2.data;
            pt_2.data = temporary;
            tmp = tmp.link;
            cnt--;
        }
    }
}


